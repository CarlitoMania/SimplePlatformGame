#pragma once
#ifndef CIRCLE
#define CIRCLE
#include <SFML/Graphics.hpp>


// Point-point distance
float distance(sf::Vector2f a, sf::Vector2f b)
{
	return sqrt(abs(a.x - b.x) + abs(a.y - b.y));
}


class Circle : public sf::CircleShape
{
public:
	// Constructor.
	Circle(float radius) : sf::CircleShape(radius)
	{
		setOrigin(radius, radius);
	}

	// Collision detector.
/*	bool intersects(sf::FloatRect bounds)
	{
		sf::Vector2f a(bounds.left, bounds.top);
		sf::Vector2f b(bounds.left + bounds.width, bounds.top);
		sf::Vector2f c(bounds.left + bounds.width, bounds.top + bounds.height);
		sf::Vector2f d(bounds.left, bounds.top + bounds.height);

		float dist;

		dist = abs((b.x - a.x) * (a.y - getOrigin().y) - (a.x - getOrigin().x) * (b.y - a.y)) / distance(a, b);
		if (dist <= getRadius()) return true;

		dist = abs((c.x - b.x) * (b.y - getOrigin().y) - (b.x - getOrigin().x) * (c.y - b.y)) / distance(b, c);
		if (dist <= getRadius()) return true;

		dist = abs((d.x - c.x) * (c.y - getOrigin().y) - (c.x - getOrigin().x) * (d.y - c.y)) / distance(c, d);
		if (dist <= getRadius()) return true;

		dist = abs((a.x - d.x) * (d.y - getOrigin().y) - (d.x - getOrigin().x) * (a.y - d.y)) / distance(d, a);
		if (dist <= getRadius()) return true;

		return false;
	}*/
};
#endif // !CIRCLE

