#pragma once
#ifndef PLATFORM
#define PLATFORM
#include <SFML/Graphics.hpp>

class Platform : public sf::RectangleShape
{
public:
	Platform(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f)) : sf::RectangleShape(size) {}

	virtual void update() {}
	virtual void update(float deltaTime) {}
	virtual void moveWith(PlayerBall& player) {}
};

#endif // !PLATFORM
