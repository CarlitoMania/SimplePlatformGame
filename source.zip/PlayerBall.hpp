#pragma once
#ifndef PLAYERBALL
#define PLAYERBALL
#include <iostream>
#include "Circle.hpp"
#define DEF_ACC 7.5f	// Default acceleration.
#define DEF_VEL 12.f	// Default velocity per second.
#define DEF_GRAV 30.f	// Default gravity.


sf::Texture playerTexture;

std::vector<sf::IntRect> textures;


class PlayerBall : public Circle {	// Only one instance can exixt.
public:
	// Movement members.
	sf::Vector2f velocity = { 0.f, 0.f };
	sf::Vector2f acceleration = { 0.f, 0.f };
	float gravity = DEF_GRAV;
	const char LEFT = 'l';
	const char RIGHT = 'r';
	const char JUMP = 'j';
	const char STOP = 's';
	bool aboveGround = true;

	std::vector<sf::IntRect>::iterator texIt;
	sf::Int8 collected;


	// Constructor.
	PlayerBall() : Circle(12.f) {
		if (!playerTexture.loadFromFile("texture.png"))	std::cerr << "ERROR loading player texture" << std::endl;

		// debugging
		//setOutlineThickness(2);
		//setOutlineColor(sf::Color::Red);

		textures.push_back(sf::IntRect(0, 0, 15, 16));		//	 0 collected
		textures.push_back(sf::IntRect(49, 0, 15, 16));		//	 1 collected
		textures.push_back(sf::IntRect(464, 0, -15, 16));	//	 2 collected
		textures.push_back(sf::IntRect(80, 0, 15, 16));		//	 3 collected
		textures.push_back(sf::IntRect(432, 0, -15, 16));	//	 4 collected
		textures.push_back(sf::IntRect(416, 0, -15, 16));	//	 5 collected
		textures.push_back(sf::IntRect(145, 0, 15, 16));	//	 6 collected
		textures.push_back(sf::IntRect(384, 0, -15, 16));	//	 7 collected
		textures.push_back(sf::IntRect(177, 0, 15, 16));	//	 8 collected
		textures.push_back(sf::IntRect(352, 0, -15, 16));	//	 9 collected
		textures.push_back(sf::IntRect(272, 0, 15, 16));	//	10 collected

		collected = 0;
		texIt = textures.begin();
		setTexture(&playerTexture);
		setTextureRect(*texIt);
		playerTexture.setSmooth(true);
	}


	// Sets acceleration.
	void accelerate(char mode)
	{
		switch (mode)
		{
		case 'l':
			velocity.x = -DEF_VEL / 2.f;
			acceleration.x = -DEF_ACC;
			break;
		case 'r':
			velocity.x = DEF_VEL / 2.f;
			acceleration.x = DEF_ACC;
			break;
		case 'j':
			if (!aboveGround)  acceleration.y = -DEF_ACC * 40.f;
			break;
		case 's':
			acceleration.x = 0.f;
			velocity.x = 0.f;
		default:
			break;
		}
	}


	/*	// Updates movement according to inputs and gravity.
		void updateMovement(float deltaTime, sf::Vector2u wSize)
		{
			if (getPosition().y + getRadius() <= wSize.y)
				aboveGround = true;
			else
				aboveGround = false;

			if (aboveGround && getPosition().y + getRadius() <= wSize.y)
			{
				acceleration.y = gravity = DEF_GRAV;
			}
			else {
				gravity = 0;

			}

			velocity += acceleration * deltaTime;	// Updates velocity in function of acceleration:	v = v_0 + a*t

			// Velocity in each direction must not be higher than default.
			if (velocity.x > DEF_VEL)	velocity.x = DEF_VEL;
			if (velocity.x < -DEF_VEL)	velocity.x = -DEF_VEL;
			if (velocity.y > DEF_VEL * 2.f)	velocity.y = DEF_VEL * 2.f;
			if (velocity.y < -DEF_VEL)	velocity.y = -DEF_VEL;

			// Handle collisions with window's boundaries.
			if (getPosition().x - getRadius() <= 0 && velocity.x < 0)	// left window edge
			{
				setPosition(getRadius(), getPosition().y);
				velocity.x = 0;
			}
			if (getPosition().x + getRadius() >= wSize.x && velocity.x > 0)	// right window edge
			{
				setPosition(wSize.x - getRadius(), getPosition().y);
				velocity.x = 0;
			}
			if (getPosition().y - getRadius() < 0 && velocity.y < 0)	// top of window
			{
				setPosition(getPosition().x, getRadius());
				velocity.y = 0;
			}
			if (getPosition().y + getRadius() > wSize.y && velocity.y > 0)	// bottom of window
			{
				setPosition(getPosition().x, wSize.y - getRadius());
				velocity.y = 0;
				aboveGround = false;
			}


			sf::Transformable::move(velocity * 60.f * deltaTime);
			rotate(velocity.x * 60.f * 3.1415);	// Rotation must depend only on horizontal movement, if there actually is one.
		}
	*/

	void collect()
	{
		collected++;
		setTextureRect(*(++texIt));
	}
};

#endif // !PLAYERBALL