#pragma once

#ifndef FREQ
#define FREQ 25
#endif

#ifndef ORANGE
#define ORANGE
const sf::Color Orange(255, 128, 0);
#endif

#ifndef COLLECTABLE
#define COLLECTABLE
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include "EquilateralTriangle.hpp"


class Collectable : public EquilateralTriangle {
public:
	static const float rotateSpeedPerFrame;
	static const float rotateSpeedPerSecond;
	bool colorFlag;
	sf::Clock colorClock;	// Used to change the color of the collectable triangle.


	Collectable(float x, float y) : EquilateralTriangle(9.f) {
		colorFlag = false;
		setFillColor(sf::Color::Yellow);
		setPosition(x, y);
	}


	void update(float deltaTime)
	{
		if (this == nullptr) return;

		if (colorClock.getElapsedTime().asMilliseconds() / FREQ > 1 && colorFlag == false)
		{
			setFillColor(sf::Color::Yellow);
			colorFlag = true;
			colorClock.restart();
		}
		else if (colorClock.getElapsedTime().asMilliseconds() / FREQ > 1 && colorFlag == true)
		{
			setFillColor(Orange);
			colorFlag = false;
			colorClock.restart();
		}

		rotate(rotateSpeedPerSecond * deltaTime);
	}


};


const float Collectable::rotateSpeedPerFrame = 10.f;
const float Collectable::rotateSpeedPerSecond = rotateSpeedPerFrame * 60.f;


std::vector<Collectable> createCollectables(sf::Uint8 lvlNum) {
	std::vector<Collectable> v;

	if (lvlNum == 1)
	{
		v.push_back(Collectable(609.f, 556.f));
		v.push_back(Collectable(434.f, 482.f));
		v.push_back(Collectable(1032.f, 308.f));
		v.push_back(Collectable(900.f, 446.f));
		v.push_back(Collectable(1200.f, 182.f));
		v.push_back(Collectable(609.f, 356.f));
		v.push_back(Collectable(850.f, 104.f));
		v.push_back(Collectable(370.f, 110.f));
		v.push_back(Collectable(120.f, 100.f));
		v.push_back(Collectable(1310.f, 40.f));
	}

	if (lvlNum == 2) {
		
		v.push_back(Collectable(612.f, 540.f));
		v.push_back(Collectable(950.f, 684.f));
		v.push_back(Collectable(1312.f, 420.f));
		v.push_back(Collectable(913.f, 444.f));
		v.push_back(Collectable(52.5, 372.f));
		v.push_back(Collectable(753.f, 180.f));
		v.push_back(Collectable(1333.f, 213.f));
		v.push_back(Collectable(1073.f, 69.f));
		v.push_back(Collectable(173.f, 60.f));
		v.push_back(Collectable(1273.f, 24.f));
	}

	return v;
}


void updateCollectables(std::vector<Collectable>& collectables, float deltaTime) {
	for (std::vector<Collectable>::iterator i = collectables.begin(); i != collectables.end(); i++) {
		i->update(deltaTime);
	}
}

void drawCollectables(std::vector<Collectable>& collectables, sf::RenderWindow& window)
{
	for (std::vector<Collectable>::iterator i = collectables.begin(); i != collectables.end(); i++) {
		window.draw(*i);
	}
}

#endif // !COLLECTABLE

