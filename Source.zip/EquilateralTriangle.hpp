#pragma once
#ifndef EQUILATERALTRIANGLE
#define EQUILATERALTRIANGLE
#include <SFML/Graphics.hpp>

class EquilateralTriangle : public sf::CircleShape {
public:
	EquilateralTriangle(float radius) : sf::CircleShape::CircleShape(radius, 3) {
		setOrigin(radius, radius);
	};
};

#endif // !EQUILATERALTRIANGLE
